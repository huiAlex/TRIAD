package edu.nd.dronology.services.extensions.missionplanning;

public class MissionExecutionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6239074784039693199L;

	public MissionExecutionException(String message) {
		super(message);
	}

}
