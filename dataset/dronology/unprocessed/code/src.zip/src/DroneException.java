package edu.nd.dronology.core.exceptions;

/**
 * @author Michael
 *
 */
public class DroneException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6599291683788888263L;

	/**
	* 
	*/

	public DroneException(String msg) {
		super(msg);
	}
}
