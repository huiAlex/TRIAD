package edu.nd.dronology.core.vehicle.uav;

public class LandingStrategy implements IStopStrategy {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
