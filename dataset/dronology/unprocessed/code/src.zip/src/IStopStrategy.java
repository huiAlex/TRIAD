package edu.nd.dronology.core.vehicle.uav;

public interface IStopStrategy {

	void execute();

}
