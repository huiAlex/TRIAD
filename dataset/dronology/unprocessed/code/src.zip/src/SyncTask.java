package edu.nd.dronology.services.extensions.missionplanning.tasks;

public class SyncTask extends AbstractMissionTask {

	protected SyncTask(String uavID, String taskName) {
		super(uavID, taskName);
	}
}