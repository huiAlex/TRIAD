package edu.nd.dronology.core.util;

/**
 * Use as dummy object handy for "synchronized(dummy)" blocks.
 * 
 * @author Michael Vierhauser
 * 
 */
public class DummyLockObject {

}
