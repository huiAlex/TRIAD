package edu.nd.dronology.services.core.message;

public class InfoNotification {

	
	//message
	//severity warning/info/error
	//type "battery"
	// infrastrucuture... 
}
