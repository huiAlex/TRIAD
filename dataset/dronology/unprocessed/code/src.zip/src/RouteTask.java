package edu.nd.dronology.services.extensions.missionplanning.tasks;

public class RouteTask extends AbstractMissionTask {

	protected RouteTask(String uavID, String taskName) {
		super(uavID, taskName);
	}
}