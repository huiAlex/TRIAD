package edu.nd.dronology.core.vehicle;

public interface IManagedDroneStateChangeListener {

	public void notifyStateChange();

}
